# Rail-Lane-Lines
Detecting rails, including curved and straight rails

run pipline.py 

For a detailed explanation, please refer to the CSDN blog content

https://blog.csdn.net/zt1091574181/article/details/88635739
