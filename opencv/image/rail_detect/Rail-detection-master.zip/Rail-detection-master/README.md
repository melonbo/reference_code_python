# Rail-detection
Detecte the RailWay
A picture with Rail Detection
You can use the .py file to detect Rail

For a detailed explanation, please refer to the CSDN blog content

https://blog.csdn.net/zt1091574181/article/details/88565580
